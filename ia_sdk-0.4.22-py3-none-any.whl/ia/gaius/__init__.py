"""Client library for interacting with Intelligent Artifacts' GAIuS agents."""
